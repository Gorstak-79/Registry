This (sub)folder(s) contain(s) the source code of Reg2exe
Reg2exe is published under the GNU General Public License (see License.txt)