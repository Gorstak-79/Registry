This folder contains files exclusive required by Reg2exe

Please note that the Reg2exe.exe file is the final 'converted' exefile where the
regestry data is 'attached' to. It's the compiled selfreg.pb, and included in
the real reg2exe project as ressource, BIN / SELFREG.EXE

After compiling, add the additional Version information
Compress it (UPX 1.25): UPX.EXE --best --compress-icons=0 reg2exe.exe
In Visual Basic, load the reg2exe project, and add it to the resources (requires
VB Resource Editor, or directly include in the reg2exe.res file):
Resource type: "BIN", ID: "SELFREG.EXE"